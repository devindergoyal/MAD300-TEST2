//
//  Condominium.swift
//  LabTest2_Ques3
//
//  Created by MacStudent on 2017-10-13.
//  Copyright © 2017 MacStudent. All rights reserved.
//

// DEVINDER GOYAL | C0713493

// References: Stackoverflow | WeheartSwift | WWW

import Foundation

class Condominium
{
    public private(set) var name_of_condominium : String = ""
    public private(set) var built_in_year : Int = 0
    public private(set) var number_of_apartments : Int = 0
    
    //Getters
    
    func getNameOfCondominium() -> String
    {
        return name_of_condominium
    }
    
    func getBuiltInYear() -> Int
    {
        return built_in_year
    }
    
    func getNumOfApartments() -> Int
    {
        return number_of_apartments
    }
    
    //Setters
    
    func setNameOfCondominium(_name_of_condominium : String)
    {
        name_of_condominium = _name_of_condominium
    }
    
    func setBuiltInYear(_built_in_year : Int)
    {
        built_in_year = _built_in_year
    }
    
    func setNumOfApartments(_number_of_apartments : Int)
    {
        number_of_apartments = _number_of_apartments
    }
}
