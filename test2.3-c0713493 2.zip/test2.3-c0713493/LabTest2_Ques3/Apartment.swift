//
//  Apartment.swift
//  LabTest2_Ques3
//
//  Created by MacStudent on 2017-10-13.
//  Copyright © 2017 MacStudent. All rights reserved.
//

// DEVINDER GOYAL | C0713493

// References: Stackoverflow | WeheartSwift | WWW

import Foundation

class Apartment : Condominium
{
    public private(set) var apartment_floor : Array<Int> = []
    public private(set) var apartment_number : Array<Int> = []
    public private(set) var apartment_size : Array<Double> = []
    public private(set) var apartment_noOfrooms : Array<Int> = []
    public private(set) var apartment_rent : Array<Double> = []
    public private(set) var apartment_rentstartdate : Array<String> = []
    public private(set) var apartment_rentfinishdate : Array<String> = []
    
    
    func calVacantApartments(aprtmentobjj : Apartment, tenantObjj : Tenant) -> Int
    {
        let apartmentNum = aprtmentobjj.getApartmentNumber()
        let tenantNum = tenantObjj.getNameOfTenant()
        var counter = 0
        
        if(apartmentNum.count > tenantNum.count)
        {
            counter += apartmentNum.count - tenantNum.count
        }
        
        return counter
    }
    
    func calTotalIncome(aprtmentobjj : Apartment, tenantObjj : Tenant) -> Double
    {
        let apartmentNum = aprtmentobjj.getApartmentNumber()
        let tenantNum = tenantObjj.getNameOfTenant()
        var totalLandlordEarning : Double = 0.0
        
        if(apartmentNum.count > tenantNum.count)
        {
            for i in 0..<tenantNum.count
            {
                totalLandlordEarning += aprtmentobjj.apartment_rent[i]
            }
        }
        
        return totalLandlordEarning
    }
    
    
    //Getters
    
    func getApartmentFloor() -> Array<Int>
    {
        return apartment_floor
    }
    
    func getApartmentNumber() -> Array<Int>
    {
        return apartment_number
    }
    
    func getApartmentSize() -> Array<Double>
    {
        return apartment_size
    }
    
    func getApartmentNoOfRooms() -> Array<Int>
    {
        return apartment_noOfrooms
    }
    
    func getApartmentRent() -> Array<Double>
    {
        return apartment_rent
    }
    
    func getApartmentRentStartDate() -> Array<String>
    {
        return apartment_rentstartdate
    }
    
    func getApartmentRentFinishDate() -> Array<String>
    {
        return apartment_rentfinishdate
    }
    
    
    //Setters
    
    func setApartmentFloor(_apartment_floor : Array<Int>)
    {
        apartment_floor = _apartment_floor
    }
    
    func setApartmentNumber(_apartment_number : Array<Int>)
    {
        apartment_number = _apartment_number
    }
    
    func setApartmentSize(_apartment_size : Array<Double>)
    {
        apartment_size = _apartment_size
    }
    
    func setApartmentNoOfRooms(_apartment_noOfrooms : Array<Int>)
    {
        apartment_noOfrooms = _apartment_noOfrooms
    }
    
    func setApartmentRent(_apartment_rent : Array<Double>)
    {
        apartment_rent = _apartment_rent
    }
    
    func setApartmentRentStartDate(_apartment_rentstartdate : Array<String>)
    {
        apartment_rentstartdate = _apartment_rentstartdate
    }
    
    func setApartmentRentFinishDate(_apartment_rentfinishdate : Array<String>)
    {
        apartment_rentfinishdate = _apartment_rentfinishdate
    }
}
