//
//  main.swift
//  LabTest2_Ques3
//
//  Created by MacStudent on 2017-10-13.
//  Copyright © 2017 MacStudent. All rights reserved.
//

// DEVINDER GOYAL | C0713493

// References: Stackoverflow | WeheartSwift | WWW

import Foundation

var condominiumObj = Condominium()
condominiumObj.setNameOfCondominium(_name_of_condominium: "Victoria Park BVLD")
condominiumObj.setBuiltInYear(_built_in_year: 1998)
condominiumObj.setNumOfApartments(_number_of_apartments: 100)

var apartmentObj = Apartment()
apartmentObj.setApartmentFloor(_apartment_floor: [1, 2, 3, 4, 5, 6, 7, 8])
apartmentObj.setApartmentNumber(_apartment_number: [101, 102, 103, 104, 105, 106, 107, 108])
apartmentObj.setApartmentSize(_apartment_size: [1.5, 2.5, 1.7, 1.8, 2.0, 1.5, 2.5, 1.5])
apartmentObj.setApartmentNoOfRooms(_apartment_noOfrooms: [2, 3, 2, 4, 5, 1, 5, 6])
apartmentObj.setApartmentRent(_apartment_rent: [450.00, 545.00, 896.00, 725.00, 653.00, 156.15, 153.5, 900.00])
apartmentObj.setApartmentRentStartDate(_apartment_rentstartdate: ["2017-05-01", "2017-05-01", "2017-05-01", "2017-05-01", "2017-05-01", "2017-05-01", "2017-05-01", "2017-05-01"])
apartmentObj.setApartmentRentFinishDate(_apartment_rentfinishdate: ["2017-10-30", "2017-10-30", "2017-10-30", "2017-10-30", "2017-10-30", "2017-10-30", "2017-10-30", "2017-10-30"])

var tenantObj = Tenant()
tenantObj.setNameOfTenant(_name_of_tenant: ["Bill Gates", "Elon Musk", "Warren Buffet", "Bella Murran", "Jennifer Lawrence", "Adrani Simsons"])
tenantObj.setGender(_gender: ["M", "M", "M","F","F","F"])
tenantObj.setPassportId(_passportId: [0175556, 08976543, 0565869, 0569536, 3556664, 5343433])
tenantObj.setSalary(_salary: [2500.00, 1000.00, 1985.00, 653.00, 455.00, 566.00])

//Report 1

//var availableApartments = apartmentObj.calVacantApartments(aprtmentobjj : apartmentObj, tenantObjj : tenantObj)
//print("Number of Available Apartments \(availableApartments)")


//Report 2

//var totalEarningOfLandlord = apartmentObj.calTotalIncome(aprtmentobjj : apartmentObj, tenantObjj : tenantObj)
//print("Total Earning of Landlord from rent \(totalEarningOfLandlord)")

//Report 3

//var numOfMalesAndFemales = tenantObj.calMalesFemalesAvg(tenantObj : tenantObj)

