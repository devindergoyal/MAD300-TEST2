//
//  Tenant.swift
//  LabTest2_Ques3
//
//  Created by MacStudent on 2017-10-13.
//  Copyright © 2017 MacStudent. All rights reserved.
//

// DEVINDER GOYAL | C0713493

// References: Stackoverflow | WeheartSwift | WWW

import Foundation


class Tenant : Apartment
{
    public private(set) var name_of_tenant : Array<String> = []
    public private(set) var gender : Array<String> = []
    public private(set) var passportId : Array<Int> = []
    public private(set) var salary : Array<Double> = []
    
    func calMalesFemalesAvg(tenantObj : Tenant)
    {
        var malesCounter = 0
        var femalesCounter = 0
        var avgMalesSalary = 0.0
        var avgFemalesSalary = 0.0
        
        var salary = tenantObj.salary
        var maleIndex:[Int]=[]
        var femaleIndex:[Int]=[]
        var c=0;
        for i in tenantObj.gender
        {
            if(i == "M")
            {
                malesCounter += 1
                avgMalesSalary=avgMalesSalary+salary[c]
                maleIndex.append(c)
            }
            else
            {
                femalesCounter += 1
                femaleIndex.append(c)
                avgFemalesSalary=avgFemalesSalary+salary[c]
            }
            c += 1
        }
        var j:Int=0;
        var avgMaleSalaryFinal:Int=0
        let malesCount = maleIndex.count
        if(malesCount != 0){
            j = Int(avgMalesSalary)
            avgMaleSalaryFinal = j/malesCount
        }
        
        var fj = 0
        var avgFemaleSalaryFinal = 0
        let femaleCount = femaleIndex.count
        if(femaleCount != 0){
            fj = Int(avgFemalesSalary)
            avgFemaleSalaryFinal = fj/femaleCount
        }
        
        print("Male's Average Salary: \(avgMaleSalaryFinal)")
        print("Female's Average Salary: \(avgFemaleSalaryFinal)")
        print("Male Tenants Available:  \(malesCounter)")
        print("Female Tenants Avaible: \(femalesCounter)")
    }
    
    
    //Getters
    
    func getNameOfTenant() -> Array<String>
    {
        return name_of_tenant
    }
    
    func getGender() -> Array<String>
    {
        return gender
    }
    
    func getPassportId() -> Array<Int>
    {
        return passportId
    }
    
    func getSalary() -> Array<Double>
    {
        return salary
    }

    
    //Setters
    
    func setNameOfTenant(_name_of_tenant : Array<String>)
    {
        name_of_tenant = _name_of_tenant
    }
    
    func setGender(_gender : Array<String>)
    {
        gender = _gender
    }
    
    func setPassportId(_passportId : Array<Int>)
    {
        passportId = _passportId
    }
    
    func setSalary(_salary : Array<Double>)
    {
        salary = _salary
    }

}
