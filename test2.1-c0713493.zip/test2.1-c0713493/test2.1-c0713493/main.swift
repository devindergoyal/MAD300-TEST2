//
//  main.swift
//  test2.1-c0713493
//
//  Created by MacStudent on 2017-10-13.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import Foundation


// Answer 1

var fulltimeemp = fulltime(ename: ["Aliza"], ecountry: ["England"], ebenefits: ["Free Car Service"], sal: [52036.23], emp_bonus: [2569.32])


var parttimeemp = parttimne(ename: ["Gal Gadot"], ecountry: ["Syria"], ebenefits: ["Free Medical Insurance"], hr: [45.30], payrate: [45.00])


print ("FullTime Employee Name =",fulltimeemp.getempname(actionindex: 0),",","Salary",fulltimeemp.calulateearning(salary: fulltimeemp.getsalary(actionindex: 0),bonus: fulltimeemp.getbonus (actionindex: 0)))


print ("PartTime Emplpyee Name=" , parttimeemp.getempname(actionindex: 0),",", "Earnings = ",parttimeemp.calulateearning(hour: parttimeemp.gethour(actionindex: 0), rate: parttimeemp.getpayrate(actionindex: 0)))

